/** Automatically generated file. DO NOT MODIFY */
package com.meneses_nicolefrances.act02;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}